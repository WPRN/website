/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateProject = `subscription OnCreateProject {
  onCreateProject {
    id
    name
    description
    type
    status
    field
    country
    location
    zone
    contact_firstname
    contact_lastname
    contact_entity
    url
    date
    time
    pubId
    createdAt
    state
    thematics
  }
}
`;
export const onUpdateProject = `subscription OnUpdateProject {
  onUpdateProject {
    id
    name
    description
    type
    status
    field
    country
    location
    zone
    contact_firstname
    contact_lastname
    contact_entity
    url
    date
    time
    pubId
    createdAt
    state
    thematics
  }
}
`;
export const onDeleteProject = `subscription OnDeleteProject {
  onDeleteProject {
    id
    name
    description
    type
    status
    field
    country
    location
    zone
    contact_firstname
    contact_lastname
    contact_entity
    url
    date
    time
    pubId
    createdAt
    state
    thematics
  }
}
`;
