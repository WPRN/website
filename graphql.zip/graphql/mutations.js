/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const newProject = /* GraphQL */ `
  mutation NewProject($input: CreateProjectInput!) {
    newProject(input: $input)
  }
`;
export const editProject = /* GraphQL */ `
  mutation EditProject($input: EditProjectInput!) {
    editProject(input: $input)
  }
`;
export const newContact = /* GraphQL */ `
  mutation NewContact($input: CreateContactInput!) {
    newContact(input: $input)
  }
`;
export const verifyEmail = /* GraphQL */ `
  mutation VerifyEmail($id: String!, $key: String!) {
    verifyEmail(id: $id, key: $key)
  }
`;
